# Kavinthan Jeyasingam Portfolio Website

A clean, responsive portfolio website for a Graduate / Assistant Structural Engineer.

## Folder Structure

```text
kavinthan-portfolio/
  index.html
  style.css
  script.js
  assets/
    Kavinthan-Jeyasingam-CV.pdf
```

## How to Run Locally

Open `index.html` directly in your browser.

## How to Publish on GitHub Pages

1. Create a new GitHub repository, for example: `kavinthan-portfolio`.
2. Upload all files from this folder.
3. Go to repository `Settings`.
4. Click `Pages`.
5. Under `Build and deployment`, choose:
   - Source: `Deploy from a branch`
   - Branch: `main`
   - Folder: `/root`
6. Save.
7. GitHub will give you a live portfolio URL.

## Where to Add Future Projects

Open `index.html` and find this section:

```html
<section id="projects" class="section">
```

Replace the placeholder project cards with your real project details.

## How to Change Contact Details

Open `index.html` and update the contact section:

```html
<section id="contact" class="section contact-section">
```

## How to Replace CV

Put your latest CV PDF inside the `assets` folder and rename it:

```text
Kavinthan-Jeyasingam-CV.pdf
```

Or update the CV link inside `index.html`.
